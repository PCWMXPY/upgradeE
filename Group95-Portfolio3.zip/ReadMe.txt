To Test, we have some suggestion

If you are not a League of Legend player
You can find a summoner ID in featured game to test live game feature
If you are not Familiar with this game you can compare the featured game and game history to test history.

The API of game history is not work really well
Please run more times to go through it, is the SERVER's ISSUE!!
Run more times will make it work fine

Thanks for your patient
